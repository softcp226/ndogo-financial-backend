// (() => {
//   if (
//     window.location.href.includes("http://www.zionintercontinentalb.com") ||
//     window.location.href.includes("http://zionintercontinentalb.com")
//   ) {
//     window.location.replace("https://www.zionintercontinentalb.com/");
//   }
// })();
